$(document).ready(function() {
    $("div.entry").css({
        "border": "1px solid black",
        "border-radius": "10px",
        "padding": "10px",
        "background": "white"
    });
})
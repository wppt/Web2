<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
  
?>
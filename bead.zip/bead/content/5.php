<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Kiegészítések</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>
            Ezt az oldalt csak regisztrált felhasználók és az admin láthatja
          </p>
        </div>
      </div>
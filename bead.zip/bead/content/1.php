<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title"><a href=".">Bemutatkozás</a></h2>
        <p class="meta"><span class="date">2018.04.10.</span><span class="posted">Beküldte: Admin</span></p>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>A 400v Corporation egy szebb és biztonságosabb jövőért létrehozott cég. Jelszavunk a biztonságos szórakoztatás garantálása, melyet
          különleges, erre a célre kifejlesztett mesterséges intelligenciával ellátott elektromos házi, illetve harcra kiképzett kecskék gyártásával
          kíván elérni.
          </p>
          <p class="links"><a href="#">Read More</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" title="b0x w">Comments</a></p>
        </div>
      </div>

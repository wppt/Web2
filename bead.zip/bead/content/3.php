<?php
    if(isset($_POST['felhasznalo']) && isset($_POST['jelszo']) && isset($_POST['vezeteknev']) && isset($_POST['utonev'])) {
        try {
            $dbh = new PDO('mysql:host=localhost;dbname=web2', 'root', '',
                            array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
            $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
            $sqlSelect = "select fh_id from motor_felhasznalok where bejelentkezes = :bejelentkezes";
            $sth = $dbh->prepare($sqlSelect);
            $sth->execute(array(':bejelentkezes' => $_POST['felhasznalo']));
            if($row = $sth->fetch(PDO::FETCH_ASSOC)) {               
                $ujra = "true";
            }
            else {
                $sqlInsert = "insert into motor_felhasznalok(fh_id, fh_fnev, fh_tnev, jelszo)
                              values(0, :csaladinev, :utonev, :bejelentkezes, :jelszo)";
                $stmt = $dbh->prepare($sqlInsert); 
                $stmt->execute(array(':csaladinev' => $_POST['vezeteknev'], ':utonev' => $_POST['utonev'],
                                     ':bejelentkezes' => $_POST['felhasznalo'], ':jelszo' => sha1($_POST['jelszo']))); 
                if($count = $stmt->rowCount()) {
                    $newid = $dbh->lastInsertId();
                                        
                    $ujra = false;
                }
                else {
                    $uzenet = "A regisztráció nem sikerült.";
                    $ujra = true;
                }
            }
        }
        catch (PDOException $e) {
            echo "Hiba: ".$e->getMessage();
        }      
    }

?>
      <div class="post">       
        <div style="clear: both;">&nbsp;</div>
        <div class="entry belepes">
          <form action="." method="post">
            <fieldset>
            <legend>Regisztráció</legend>
            <br>
            <input type="text" name="vezeteknev" placeholder="vezetéknév" required><br><br>
            <input type="text" name="utonev" placeholder="utónév" required><br><br>
            <input type="text" name="felhasznalo" placeholder="felhasználói név" required><br><br>
            <input type="password" name="jelszo" placeholder="jelszó" required><br><br>
            <input type="submit" name="regisztracio" value="Regisztráció">
            <br>&nbsp;
            </fieldset>
          </form>
        </div>
      </div>
      
      
      
<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Célok</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>
            Szeretnénk elérni, hogy legfeljebb tíz éven belül minden háztartásban megtalálható legyen legalább 1 modellünk, és ezzel megkönnyítsük az emberek életét minden téren.
          </p>
        </div>
      </div>
<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Admin oldal</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>
            Ezt az oldalt csak adminként belépve szabad látnunk.
          </p>
        </div>
      </div>
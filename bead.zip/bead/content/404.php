<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Hiba 404</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>Menjen rá egy menüpontra</p>
        </div>
      </div>

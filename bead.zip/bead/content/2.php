<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Elérhetőségek</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>
            Cím: Budapest, X. kerület ABC utca 123.
          <p>Tel.: 06-11-222-3456</p>
          <p>Email: 400vcorp@dea.com</p>
            A megrendeléseket jelenleg csak személyesen vesszük fel, de bármilyen információval szivesen szolgálunk ha telefonon vagy emailben keres fel bennünket.
          </p>
        </div>
      </div>
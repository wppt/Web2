<?php
  if (!isset($user)) {
    header("location: ../index.php");
  }
?>
      <div class="post">
        <h2 class="title">Alapinformációk</h2>
        <div style="clear: both;">&nbsp;</div>
        <div class="entry">
          <p>
            Jelenleg egy házi és egy örző/védő modellünket lehet megrendelni:
            
           <p> A szórakoztatásra kifejlesztett FLFFYNTR-3 modell kifejezetten a családok igényeit tudja kielégiteni, hiszen játékos természetével bármely korosztályt elvarázsolja.</p>
            
            Harci modellünk, a WARGOAT-1000 tökéletes biztonságérzetet nyújt minden körülmény között.
          </p>
        </div>
      </div>

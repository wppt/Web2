<?php
  header("Content-type: text/html; charset=utf-8");
  include_once("includes/dbnames.inc.php");
  include_once("includes/connect.inc.php");
  include_once("includes/user.class.php");
  include_once("includes/page.class.php");
?>
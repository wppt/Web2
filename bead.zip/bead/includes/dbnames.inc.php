<?php
  define("DB_SYSTEM", "mysql");
  define("DB_HOST",   "localhost");
  define("DB_NAME",   "web2");
  define("USER_NAME", "root");
  define("PASSWORD",  "");
  
  define("MOTOR_OLDALAK",      "motor_oldalak");
  define("MOTOR_FELHASZNALOK", "motor_felhasznalok");
  define("MOTOR_BLOKKOK",      "motor_blokkok");
  define("MOTOR_SZINTEK",      "motor_szintek");
?>
